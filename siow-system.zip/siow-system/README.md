# Siow System

Plataforma modular da **Siow System Tecnologia**. Este repositório contém a plataforma
(autenticação, RBAC, auditoria, documentos, notificações, filas) e o primeiro módulo:

**Financeiro** — gestão de contratos e recebimentos de órgãos públicos (PM, CM, …):
sincronização automática com o Portal do Cliente, histórico financeiro, dashboard,
notas fiscais, contratos e conta corrente, certidões, agenda financeira, cobranças,
mensagens ao cliente, ordens de serviço, relatórios (PDF/XLSX/CSV) e auditoria.

Documentação da arquitetura: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md).

## Stack

TypeScript estrito · Node 22/24 LTS · NestJS 11 · Prisma 6 · PostgreSQL 16 · Redis 7 + BullMQ ·
MinIO/S3 · Next.js 15 (App Router) · Tailwind CSS 4 · TanStack Query · Zod · pnpm workspaces.

## Rodando localmente

Pré-requisitos: Node ≥ 22, pnpm ≥ 9, Docker.

```bash
cp .env.example .env            # ajuste os segredos (JWT_*), se quiser
pnpm install
pnpm infra:up                   # Postgres, Redis, MinIO (+ bucket)
pnpm db:generate
pnpm db:migrate                 # cria o schema (prisma migrate dev --name init)
SEED_SAMPLE_ENTITIES=true pnpm db:seed   # papéis, permissões, admin, templates, configs (+2 entidades de teste)
pnpm dev                        # api :3001, web :3000, worker
```

Acesse http://localhost:3000 — usuário inicial `admin@empresa.com.br` / `Admin@12345`
(definidos em `SEED_ADMIN_*` no `.env`). Troque a senha no primeiro acesso.

Comandos úteis:

| Comando | Descrição |
|---|---|
| `pnpm dev:api` / `dev:web` / `dev:worker` | subir apenas um app |
| `pnpm typecheck` | `tsc --noEmit` em todos os pacotes |
| `pnpm test` | testes (parser do portal, utilidades) |
| `pnpm db:studio` | Prisma Studio |
| `pnpm infra:down` | derrubar a infraestrutura |

## Fluxo básico de uso

1. **Entidades → Nova entidade** (ou *Importar CSV/XLSX* com colunas `tipo, entidade, municipio, uf, url, nome_completo`).
2. **Sincronizar agora** na entidade (ou *Sincronizar todas* em Sincronização). O worker lê o portal,
   grava contratos, notas (com histórico), certidões, e aponta divergências para verificação.
3. Acompanhe no **Dashboard** (filtros globais), na **ficha da entidade** (abas), nas **Notas fiscais**
   (pendentes/pagas/todas, cobrança, alteração manual com justificativa), na **Agenda** e nos **Relatórios**.

## Estrutura

```
apps/api        NestJS — modules/platform/* e modules/financeiro/*
apps/worker     BullMQ — sync, documentos, verificações diárias, agendamentos
apps/web        Next.js — app/(app)/financeiro/*, admin, notificações
packages/db     Prisma schema + seed
packages/shared enums/rótulos, schemas Zod, tipos, utilidades
packages/integrations  BillingProvider + AssesiPortalProvider (HTTP + parser)
packages/sync-core     aplicação de snapshot com histórico/reconciliação/conflitos
packages/queue  filas e payloads
packages/storage S3 + DocumentStore (dedupe por checksum, URLs pré-assinadas)
infra/          docker-compose (Postgres, Redis, MinIO)
```

## Produção (resumo)

- `NODE_ENV=production`, `COOKIE_SECURE=true`, TLS no proxy reverso, segredos fortes (`openssl rand -base64 48`).
- `pnpm db:deploy` (migrations) e `pnpm db:seed` (idempotente) a cada deploy.
- API e worker rodam com `pnpm --filter @siow/api start` / `@siow/worker start`; web com `next build && next start`.
- Redis e Postgres com backup; bucket S3 privado (nunca público).
- Configure `WHATSAPP_*` / `SMTP_*` para envio automático — sem eles, as mensagens ficam em modo de envio manual.
