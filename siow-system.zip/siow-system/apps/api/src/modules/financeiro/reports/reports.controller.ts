import { Controller, ForbiddenException, Get, Query, Res } from '@nestjs/common';
import type { Response } from 'express';
import { REPORT_KEYS, reportRequestSchema, type ReportRequest } from '@siow/shared';
import { AuditService } from '../../../common/audit/audit.service.js';
import { Ctx, RequirePermissions, type RequestContext } from '../../../common/auth/decorators.js';
import { zod } from '../../../common/zod/zod.pipe.js';
import { toCsv, toPdf, toXlsx } from './exporters.js';
import { ReportsService } from './reports.service.js';

const REPORT_LABELS: Record<(typeof REPORT_KEYS)[number], string> = {
  financial_overview: 'Financeiro geral',
  invoices: 'Notas fiscais (pendentes / pagas / todas)',
  receivables_by_entity: 'Recebíveis por entidade',
  defaulters: 'Inadimplentes',
  payments: 'Recebimentos',
  average_days_to_pay: 'Tempo médio para recebimento',
  contracts: 'Contratos',
  contracts_expiring: 'Contratos vencendo',
  certificates: 'Certidões (válidas / vencendo / vencidas)',
  service_orders: 'Ordens de serviço',
  tasks: 'Agenda financeira',
  collections: 'Cobranças realizadas',
  invoice_history: 'Histórico financeiro',
};

@Controller('financeiro/reports')
export class ReportsController {
  constructor(
    private readonly reports: ReportsService,
    private readonly audit: AuditService,
  ) {}

  @Get('catalog')
  @RequirePermissions('reports.read')
  catalog() {
    return REPORT_KEYS.map((key) => ({ key, label: REPORT_LABELS[key] }));
  }

  @Get()
  @RequirePermissions('reports.read')
  async run(@Ctx() ctx: RequestContext, @Query(zod(reportRequestSchema)) req: ReportRequest, @Res({ passthrough: true }) res: Response) {
    const result = await this.reports.run(req);
    if (req.format === 'json') return result;
    if (!ctx.user.permissions.includes('reports.export')) throw new ForbiddenException('Permissão necessária: reports.export');
    await this.audit.log(ctx, { action: 'EXPORT', resource: 'report', resourceId: req.report, after: { format: req.format, filters: result.filters } });
    const stamp = result.generatedAt.slice(0, 16).replace(/[:T]/g, '-');
    const name = `${req.report}-${stamp}`;
    if (req.format === 'csv') {
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${name}.csv"`);
      return toCsv(result);
    }
    if (req.format === 'xlsx') {
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${name}.xlsx"`);
      return toXlsx(result);
    }
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${name}.pdf"`);
    return toPdf(result);
  }
}
