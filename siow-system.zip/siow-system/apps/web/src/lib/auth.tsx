'use client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useRouter } from 'next/navigation';
import { createContext, useContext, useEffect } from 'react';
import type { CurrentUser } from '@siow/shared';
import { api, ApiError } from './api';

const AuthContext = createContext<{ user: CurrentUser | null; can: (p: string) => boolean; logout: () => Promise<void> }>({ user: null, can: () => false, logout: async () => {} });

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const qc = useQueryClient();
  const { data, error, isLoading } = useQuery({ queryKey: ['me'], queryFn: () => api<CurrentUser>('/auth/me'), retry: false });

  useEffect(() => {
    if (error instanceof ApiError && error.status === 401) router.replace('/login');
  }, [error, router]);

  if (isLoading) return <div className="flex h-screen items-center justify-center text-sm text-ink-3">Carregando…</div>;
  if (!data) return null;

  const can = (p: string): boolean => data.permissions.includes(p);
  const logout = async (): Promise<void> => {
    await api('/auth/logout', { method: 'POST' });
    qc.clear();
    router.replace('/login');
  };
  return <AuthContext.Provider value={{ user: data, can, logout }}>{children}</AuthContext.Provider>;
}

export const useAuth = () => useContext(AuthContext);
