/* eslint-disable no-console */
import { PrismaClient, TaskType } from '@prisma/client';
import argon2 from 'argon2';

const prisma = new PrismaClient();

/**
 * Catálogo de permissões granulares. Papéis são apenas agrupamentos —
 * a autorização sempre verifica a permissão, nunca o nome do papel.
 */
export const PERMISSIONS: Record<string, string> = {
  'entities.read': 'Visualizar entidades',
  'entities.write': 'Cadastrar/editar entidades e fontes de dados',
  'contacts.read': 'Visualizar contatos (dados pessoais)',
  'contacts.write': 'Gerenciar contatos',
  'contracts.read': 'Visualizar contratos',
  'contracts.write': 'Cadastrar/editar contratos e aditivos',
  'invoices.read': 'Visualizar notas fiscais',
  'invoices.override': 'Alterar manualmente dados financeiros (exige justificativa)',
  'invoices.reconcile': 'Resolver reconciliações e conflitos de sincronização',
  'payments.read': 'Visualizar pagamentos e recebimentos',
  'documents.read': 'Visualizar/baixar documentos',
  'documents.write': 'Enviar documentos',
  'certificates.read': 'Visualizar certidões',
  'certificates.manage': 'Gerenciar certidões',
  'tasks.read': 'Visualizar agenda financeira',
  'tasks.manage': 'Criar/editar/transferir tarefas',
  'collections.read': 'Visualizar cobranças',
  'collections.manage': 'Registrar cobranças e enviar mensagens',
  'service_orders.read': 'Visualizar ordens de serviço',
  'service_orders.manage': 'Gerenciar ordens de serviço e assinaturas',
  'reports.read': 'Visualizar relatórios',
  'reports.export': 'Exportar relatórios (PDF/XLSX/CSV)',
  'dashboard.read': 'Visualizar dashboard',
  'sync.read': 'Visualizar monitoramento de sincronização',
  'sync.run': 'Disparar sincronizações',
  'integrations.manage': 'Configurar integrações e mensageria',
  'templates.manage': 'Gerenciar modelos de mensagem',
  'users.manage': 'Gerenciar usuários, papéis e permissões',
  'audit.read': 'Consultar auditoria',
  'settings.manage': 'Alterar configurações do sistema',
};

const ALL = Object.keys(PERMISSIONS);
const READ_ONLY = ALL.filter((p) => p.endsWith('.read'));

const ROLES: Array<{ name: string; description: string; permissions: string[] }> = [
  { name: 'ADMINISTRADOR', description: 'Acesso total', permissions: ALL },
  {
    name: 'FINANCEIRO',
    description: 'Operação do setor financeiro',
    permissions: ALL.filter(
      (p) => !['users.manage', 'integrations.manage', 'settings.manage'].includes(p),
    ),
  },
  {
    name: 'GESTOR',
    description: 'Diretoria/gestão: leitura ampla e relatórios',
    permissions: [...READ_ONLY, 'reports.export', 'tasks.manage'],
  },
  { name: 'CONSULTA', description: 'Somente leitura', permissions: READ_ONLY },
];

const TEMPLATES = [
  {
    key: 'SERVICE_ORDER_ISSUE_REMINDER',
    name: 'Avisar cliente para emissão da ordem de serviço',
    subject: 'Emissão de ordem de serviço — competência {{competencia}}/{{exercicio}}',
    body:
      'Olá{{#contato}}, {{contato}}{{/contato}}. Identificamos que a ordem de serviço referente à competência ' +
      '{{competencia}}/{{exercicio}} ainda precisa ser emitida. Solicitamos, por gentileza, a emissão ' +
      'para darmos prosseguimento ao faturamento.\n\nAtenciosamente,\n{{empresa}}',
    variables: ['contato', 'entidade', 'competencia', 'exercicio', 'contrato', 'empresa'],
  },
  {
    key: 'INVOICE_COLLECTION',
    name: 'Cobrança de nota fiscal pendente',
    subject: 'Nota fiscal {{numeroNota}} — competência {{competencia}}/{{exercicio}}',
    body:
      'Olá{{#contato}}, {{contato}}{{/contato}}. Consta em aberto a nota fiscal nº {{numeroNota}}, ' +
      'competência {{competencia}}/{{exercicio}}, no valor de {{valor}}, emitida em {{emissao}}. ' +
      'Poderiam nos informar a previsão de pagamento?\n\nAtenciosamente,\n{{empresa}}',
    variables: [
      'contato',
      'entidade',
      'numeroNota',
      'competencia',
      'exercicio',
      'valor',
      'emissao',
      'empresa',
    ],
  },
  {
    key: 'INVOICE_COLLECTION_FOLLOWUP',
    name: 'Nova cobrança (lembrete)',
    subject: 'Lembrete — nota fiscal {{numeroNota}}',
    body:
      'Olá{{#contato}}, {{contato}}{{/contato}}. Retomamos o contato sobre a nota fiscal nº {{numeroNota}} ' +
      '({{competencia}}/{{exercicio}}, {{valor}}), que segue pendente. Ficamos à disposição para qualquer ' +
      'esclarecimento.\n\nAtenciosamente,\n{{empresa}}',
    variables: ['contato', 'entidade', 'numeroNota', 'competencia', 'exercicio', 'valor', 'empresa'],
  },
];

const SETTINGS: Array<{ key: string; value: unknown; description: string }> = [
  { key: 'certificates.expiringDays', value: 30, description: 'Dias para considerar certidão "vencendo"' },
  { key: 'contracts.expiringDays', value: 60, description: 'Dias para alertar contrato próximo do vencimento' },
  { key: 'sync.cron', value: '0 */6 * * *', description: 'Frequência da sincronização automática' },
  { key: 'sync.fetchInvoiceDocuments', value: false, description: 'Baixar automaticamente PDFs de notas durante a sincronização' },
  { key: 'company.name', value: 'Sua Empresa de Tecnologia', description: 'Nome usado em mensagens e relatórios' },
  { key: 'invoices.overdueAfterDays', value: 30, description: 'Dias após a emissão para considerar a nota em atraso' },
];

const TASK_TYPE_LABELS: Record<TaskType, string> = {
  CHARGE_CLIENT: 'Cobrar município',
  CHARGE_AGAIN: 'Cobrar novamente',
  VERIFY_PAYMENT: 'Verificar pagamento',
  REQUEST_SERVICE_ORDER: 'Solicitar ordem de serviço',
  VERIFY_SIGNATURE: 'Verificar assinatura',
  RENEW_CERTIFICATE: 'Renovar certidão',
  VERIFY_CONTRACT: 'Verificar contrato',
  SEND_DOCUMENT: 'Enviar documento',
  CONFIRM_PAYMENT: 'Confirmar pagamento',
  CUSTOM: 'Tarefa personalizada',
};

/**
 * Protege a tabela de auditoria contra UPDATE/DELETE via aplicação:
 * triggers que abortam a operação. Somente o DBA (superuser) consegue
 * remover o trigger — nunca a interface comum.
 */
async function protectAuditLog(): Promise<void> {
  await prisma.$executeRawUnsafe(`
    CREATE OR REPLACE FUNCTION audit_logs_immutable() RETURNS trigger AS $$
    BEGIN
      RAISE EXCEPTION 'audit_logs is append-only (operation % blocked)', TG_OP;
    END;
    $$ LANGUAGE plpgsql;
  `);
  await prisma.$executeRawUnsafe(`DROP TRIGGER IF EXISTS audit_logs_no_update ON audit_logs;`);
  await prisma.$executeRawUnsafe(`
    CREATE TRIGGER audit_logs_no_update BEFORE UPDATE OR DELETE ON audit_logs
    FOR EACH ROW EXECUTE FUNCTION audit_logs_immutable();
  `);
  await prisma.$executeRawUnsafe(`DROP TRIGGER IF EXISTS audit_logs_no_truncate ON audit_logs;`);
  await prisma.$executeRawUnsafe(`
    CREATE TRIGGER audit_logs_no_truncate BEFORE TRUNCATE ON audit_logs
    FOR EACH STATEMENT EXECUTE FUNCTION audit_logs_immutable();
  `);
}

async function main(): Promise<void> {
  console.log('→ permissões');
  for (const [code, description] of Object.entries(PERMISSIONS)) {
    await prisma.permission.upsert({
      where: { code },
      update: { description },
      create: { code, description },
    });
  }

  console.log('→ papéis');
  for (const r of ROLES) {
    const role = await prisma.role.upsert({
      where: { name: r.name },
      update: { description: r.description, isSystem: true },
      create: { name: r.name, description: r.description, isSystem: true },
    });
    const perms = await prisma.permission.findMany({ where: { code: { in: r.permissions } } });
    await prisma.rolePermission.deleteMany({ where: { roleId: role.id } });
    await prisma.rolePermission.createMany({
      data: perms.map((p) => ({ roleId: role.id, permissionId: p.id })),
      skipDuplicates: true,
    });
  }

  console.log('→ usuário administrador');
  const email = process.env.SEED_ADMIN_EMAIL ?? 'admin@empresa.com.br';
  const password = process.env.SEED_ADMIN_PASSWORD ?? 'Admin@12345';
  const name = process.env.SEED_ADMIN_NAME ?? 'Administrador';
  const existing = await prisma.user.findUnique({ where: { email } });
  if (!existing) {
    const passwordHash = await argon2.hash(password, { type: argon2.argon2id });
    const admin = await prisma.user.create({ data: { name, email, passwordHash } });
    const adminRole = await prisma.role.findUniqueOrThrow({ where: { name: 'ADMINISTRADOR' } });
    await prisma.userRole.create({ data: { userId: admin.id, roleId: adminRole.id } });
    console.log(`   criado ${email}`);
  } else {
    console.log('   já existe, mantido');
  }

  console.log('→ modelos de mensagem');
  for (const t of TEMPLATES) {
    await prisma.messageTemplate.upsert({
      where: { key: t.key },
      update: {},
      create: { ...t, isSystem: true },
    });
  }

  console.log('→ configurações');
  for (const s of SETTINGS) {
    await prisma.setting.upsert({
      where: { key: s.key },
      update: { description: s.description },
      create: { key: s.key, value: s.value as object, description: s.description },
    });
  }
  await prisma.setting.upsert({
    where: { key: 'tasks.typeLabels' },
    update: { value: TASK_TYPE_LABELS },
    create: { key: 'tasks.typeLabels', value: TASK_TYPE_LABELS, description: 'Rótulos dos tipos de tarefa' },
  });

  console.log('→ proteção da auditoria');
  await protectAuditLog();

  if (process.env.SEED_SAMPLE_ENTITIES === 'true') {
    console.log('→ entidades de exemplo (fontes de teste)');
    const samples = [
      { type: 'CM' as const, name: 'CÂMARA MUNICIPAL DE ARAIOSES', shortName: 'CM ARAIOSES', municipality: 'Araioses', uf: 'MA', url: 'https://assesi.com.br/adm_faturas/index.php?e=545110&t=1' },
      { type: 'CM' as const, name: 'CÂMARA MUNICIPAL DE BOM LUGAR', shortName: 'CM BOM LUGAR', municipality: 'Bom Lugar', uf: 'MA', url: 'https://www.assesi.com.br/adm_faturas/index.php?e=504673&t=1' },
    ];
    for (const s of samples) {
      const entity = await prisma.entity.upsert({
        where: { type_municipality_uf: { type: s.type, municipality: s.municipality, uf: s.uf } },
        update: {},
        create: { type: s.type, name: s.name, shortName: s.shortName, municipality: s.municipality, uf: s.uf },
      });
      await prisma.dataSource.upsert({
        where: { provider_url: { provider: 'ASSESI_PORTAL', url: s.url } },
        update: {},
        create: { entityId: entity.id, provider: 'ASSESI_PORTAL', url: s.url, label: 'Portal do Cliente' },
      });
    }
  }

  console.log('seed concluído');
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
